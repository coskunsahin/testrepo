import React from 'react';
import CostTable  from './CostTable'
import Masterform from './Masterforms'; 





function App() {
  return (
    <div className="App">
      <Masterform /> 
      <CostTable />
    </div>
    
  );
}

export default App;
